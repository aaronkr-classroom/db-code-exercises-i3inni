-- ============================================================
-- DB Final Project  (PostgreSQL)
-- 국내 관광 여행사 데이터베이스 구축
-- Student Name: 2126014
-- Student ID: 김다빈
-- ============================================================


---------------------------------------------------------------
-- 1. 테이블 생성
-- 코드 테이블 먼저 만들고, FK가 걸리는 테이블은 뒤에 생성
---------------------------------------------------------------

-- 고객등급코드: 1 최우수, 2 우수, 3 일반
CREATE TABLE class_code(
    code INT PRIMARY KEY,
    class VARCHAR(10),
    basis VARCHAR(20)
);

-- 직원업무코드
CREATE TABLE task_code(
    code INT PRIMARY KEY,
    task VARCHAR(30)
);

-- 고객
CREATE TABLE customer(
    cus_id VARCHAR(15) PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    cell CHAR(13) NOT NULL UNIQUE,
    addr VARCHAR(100),
    c_code INT DEFAULT 3,  -- 등급 안 주면 일반(3)으로
    FOREIGN KEY (c_code) REFERENCES class_code(code)
);

-- 직원
CREATE TABLE staff(
    staff_id INT PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    birthday INT NOT NULL,      -- YYMMDD
    tel CHAR(12),
    salary INT,
    t_code INT NOT NULL,
    hire_date CHAR(8) NOT NULL, -- YYYYMMDD
    FOREIGN KEY (t_code) REFERENCES task_code(code)
);

-- 여행상품
CREATE TABLE tour(
    tour_num CHAR(8) PRIMARY KEY,
    departure VARCHAR(50) NOT NULL,
    arrival VARCHAR(50) NOT NULL,
    program VARCHAR(100),
    start_dt DATE NOT NULL,
    end_dt DATE NOT NULL,
    min_num INT,
    max_num INT,
    expense INT NOT NULL,
    deposit INT,
    dept_yn CHAR(1) DEFAULT 'N',  -- 출발여부
    staff_id INT,                 -- 담당직원
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
);

-- 예약하다 (고객-여행상품 N:M 관계 테이블)
-- 같은 고객이 같은 상품을 중복 예약하면 안 되니까 두 FK를 묶어서 복합 PK로
CREATE TABLE reserve(
    cus_id VARCHAR(15),
    tour_num CHAR(8),
    res_date DATE DEFAULT CURRENT_DATE,
    dep_yn CHAR(1) DEFAULT 'N',  -- 예약금 결제여부
    exp_yn CHAR(1) DEFAULT 'N',  -- 여행경비 결제여부
    PRIMARY KEY (cus_id, tour_num),
    FOREIGN KEY (cus_id) REFERENCES customer(cus_id),
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);

-- 여기부터 보너스 테이블

-- 관광버스
CREATE TABLE tour_bus(
    bus_id INT PRIMARY KEY,
    seat INT NOT NULL,
    del_year INT  -- 출고년도
);

-- 운전기사
CREATE TABLE driver(
    driver_id INT PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    birthday CHAR(6) NOT NULL,
    cell CHAR(13) NOT NULL,
    pay INT DEFAULT 15000,  -- 시급
    cont_date CHAR(8),
    cont_term CHAR(8)       -- 계약기간(개월)
);

-- 기사배정하다
CREATE TABLE assign_driver(
    tour_num CHAR(8) PRIMARY KEY,
    driver_id INT,
    work_hour INT,
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num),
    FOREIGN KEY (driver_id) REFERENCES driver(driver_id)
);

-- 차량배정하다
CREATE TABLE assign_bus(
    tour_num CHAR(8) PRIMARY KEY,
    bus_id INT,
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num),
    FOREIGN KEY (bus_id) REFERENCES tour_bus(bus_id)
);


---------------------------------------------------------------
-- 2. 데이터 삽입
-- FK 때문에 부모 테이블부터 넣어야 함 (안 그러면 foreign key violation)
---------------------------------------------------------------

-- 등급은 3종류뿐이라 3건만
INSERT INTO class_code VALUES
(1, '최우수', '연 5회 이상 이용'),
(2, '우수', '연 2회 이상 이용'),
(3, '일반', '신규/일반 고객');

INSERT INTO task_code VALUES
(1, '여행상품관리'),
(2, '예약관리'),
(3, '관광버스배차관리'),
(4, '직원관리'),
(5, '고객관리');

INSERT INTO customer VALUES
('cust01', '김민준', '010-1111-0001', '서울시 강남구', 1),
('cust02', '이서연', '010-1111-0002', '부산시 해운대구', 2),
('cust03', '박지후', '010-1111-0003', '대구시 수성구', 3),
('cust04', '최유진', '010-1111-0004', '인천시 연수구', 3),
('cust05', '정하윤', '010-1111-0005', '광주시 북구', 3);

INSERT INTO staff VALUES
(10001, '한지원', 880101, '02-1111-0001', 3500000, 1, '20180301'),
(10002, '오세훈', 900215, '02-1111-0002', 3200000, 2, '20190401'),
(10003, '임수아', 920620, '02-1111-0003', 3000000, 3, '20200701'),
(10004, '강도윤', 850909, '02-1111-0004', 4200000, 4, '20150901'),
(10005, '윤채원', 930312, '02-1111-0005', 2900000, 5, '20210301');

INSERT INTO tour VALUES
('T0000001', '서울', '제주', 'http://tour.com/p1', '2026-07-01', '2026-07-04', 10, 30, 550000, 100000, 'N', 10001),
('T0000002', '서울', '부산', 'http://tour.com/p2', '2026-07-10', '2026-07-12', 15, 40, 320000, 50000, 'N', 10001),
('T0000003', '부산', '경주', 'http://tour.com/p3', '2026-08-01', '2026-08-02', 8, 25, 180000, 30000, 'Y', 10002),
('T0000004', '인천', '강릉', 'http://tour.com/p4', '2026-08-15', '2026-08-17', 12, 35, 280000, 40000, 'N', 10002),
('T0000005', '대구', '여수', 'http://tour.com/p5', '2026-09-05', '2026-09-07', 10, 30, 350000, 60000, 'N', 10003);

INSERT INTO tour_bus VALUES
(1, 45, 2020),
(2, 45, 2021),
(3, 28, 2019),
(4, 28, 2022),
(5, 45, 2023);

INSERT INTO driver VALUES
(20001, '서동현', '800505', '010-2222-0001', 16000, '20200101', '24'),
(20002, '문지호', '821010', '010-2222-0002', 15000, '20210201', '12'),
(20003, '배수빈', '790715', '010-2222-0003', 17000, '20190301', '36'),
(20004, '신예준', '860323', '010-2222-0004', 15000, '20220401', '12'),
(20005, '조아인', '840828', '010-2222-0005', 16000, '20210601', '18');

INSERT INTO reserve VALUES
('cust01', 'T0000001', '2026-06-01', 'Y', 'N'),
('cust02', 'T0000001', '2026-06-02', 'Y', 'Y'),
('cust03', 'T0000002', '2026-06-03', 'N', 'N'),
('cust04', 'T0000003', '2026-06-04', 'Y', 'N'),
('cust05', 'T0000004', '2026-06-05', 'N', 'N');

INSERT INTO assign_driver VALUES
('T0000001', 20001, 32),
('T0000002', 20002, 16),
('T0000003', 20003, 16),
('T0000004', 20004, 24),
('T0000005', 20005, 24);

INSERT INTO assign_bus VALUES
('T0000001', 1),
('T0000002', 2),
('T0000003', 3),
('T0000004', 4),
('T0000005', 5);


---------------------------------------------------------------
-- 3. 인덱스
---------------------------------------------------------------

-- 도착지로 검색하는 경우가 많음 (분포도 약 1%)
CREATE INDEX tour_arrival_idx ON tour(arrival);

-- 기사 이름은 검색 + 정렬에 자주 씀 (분포도 약 2%)
CREATE INDEX driver_name_idx ON driver(name);


---------------------------------------------------------------
-- 4. 테스트 쿼리 (과제 필수 7개)
---------------------------------------------------------------

-- (1) 고객 등급 검색: 등급이 코드로 저장돼 있어서 class_code랑 조인
SELECT c.name, cc.class
FROM customer c
JOIN class_code cc ON c.c_code = cc.code
WHERE c.cus_id = 'cust01';

-- (2) 직원 담당업무 검색
SELECT s.name, t.task
FROM staff s
JOIN task_code t ON s.t_code = t.code
WHERE s.staff_id = 10001;

-- (3) 특정 여행상품을 예약한 고객 목록
SELECT c.name, r.res_date, r.dep_yn
FROM reserve r
JOIN customer c ON r.cus_id = c.cus_id
WHERE r.tour_num = 'T0000001';

-- (4) 여행상품에 배정된 기사 검색 (테이블 3개 조인)
SELECT t.departure, d.name, d.cell
FROM tour t
JOIN assign_driver a ON t.tour_num = a.tour_num
JOIN driver d ON a.driver_id = d.driver_id
WHERE t.tour_num = 'T0000001';

-- (5) 신규 고객 등록. c_code 생략하면 DEFAULT 3 들어가는지 확인용
INSERT INTO customer(cus_id, name, cell)
VALUES ('cust06', '신규고객', '010-1111-0006');

-- (6) 직원 급여 20만 원 인상
UPDATE staff
SET salary = salary + 200000
WHERE staff_id = 10001;

-- (7) 예약 1건 삭제 (복합 PK라 두 조건 다 걸어야 함)
DELETE FROM reserve
WHERE cus_id = 'cust01' AND tour_num = 'T0000001';


---------------------------------------------------------------
-- 5. 테이블 삭제
-- 생성의 역순(자식 -> 부모)으로 지워야 FK 오류가 안 남
---------------------------------------------------------------

DROP TABLE assign_bus;
DROP TABLE assign_driver;
DROP TABLE reserve;
DROP TABLE tour;
DROP TABLE driver;
DROP TABLE tour_bus;
DROP TABLE staff;
DROP TABLE customer;
DROP TABLE task_code;
DROP TABLE class_code;
